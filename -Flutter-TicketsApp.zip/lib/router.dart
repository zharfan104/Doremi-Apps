import 'package:auto_route/auto_route.dart';
import 'package:auto_route/auto_route_annotations.dart';
import 'package:izievent/view/filter.dart';
import 'package:izievent/view/home.dart';
import 'package:izievent/view/intro.dart';
import 'package:izievent/view/login.dart';
import 'package:izievent/view/splash.dart';

@MaterialAutoRouter(
  routes: <AutoRoute>[
    MaterialRoute(page: SplashScreenPage, initial: true, name: "InitialRoute"),
    //This route returns result of type [bool]
    CustomRoute<bool>(
        page: LoginPage, transitionsBuilder: TransitionsBuilders.fadeIn),
    CustomRoute<bool>(
        page: IntroPage, transitionsBuilder: TransitionsBuilders.fadeIn),
    CustomRoute<bool>(
        path: "/home/:isLogin?",
        page: HomePage,
        transitionsBuilder: TransitionsBuilders.fadeIn),
    CustomRoute<bool>(
        page: FilterPage, transitionsBuilder: TransitionsBuilders.fadeIn),

    // MaterialRoute(path: "*", page: HomePage)
  ],
)
class $Router {}
