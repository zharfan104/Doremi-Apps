import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:izievent/router.gr.dart';
import 'package:izievent/settings/HexColor.dart';
import 'package:izievent/tabs/accountPage/faq_page.dart';
import 'package:izievent/tabs/accountPage/payment/payment_page.dart';
import 'package:izievent/tabs/accountPage/settings/settings_page.dart';
import 'package:izievent/tabs/accountPage/tracking_page.dart';
import 'package:izievent/tabs/accountPage/wallet/wallet_page.dart';
import 'package:izievent/app_properties.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBlack,
      body: SafeArea(
        top: true,
        child: SingleChildScrollView(
          child: Padding(
            padding:
                EdgeInsets.only(left: 16.0, right: 16.0, top: kToolbarHeight),
            child: Column(
              children: <Widget>[
                CircleAvatar(
                  maxRadius: 48,
                  backgroundImage: AssetImage('assets/background.jpg'),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'Akbar Helbert',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
                // Container(
                //   margin: EdgeInsets.symmetric(vertical: 16.0),
                //   decoration: BoxDecoration(
                //       borderRadius: BorderRadius.only(
                //           topLeft: Radius.circular(8),
                //           topRight: Radius.circular(8),
                //           bottomLeft: Radius.circular(8),
                //           bottomRight: Radius.circular(8)),
                //       color: Colors.white,
                //       boxShadow: [
                //         BoxShadow(
                //             color: transparentYellow,
                //             blurRadius: 4,
                //             spreadRadius: 1,
                //             offset: Offset(0, 1))
                //       ]),
                //   height: 150,
                //   child: Center(
                //     child: Row(
                //       mainAxisAlignment: MainAxisAlignment.spaceAround,
                //       children: <Widget>[
                //         Column(
                //           mainAxisAlignment: MainAxisAlignment.center,
                //           children: <Widget>[
                //             IconButton(
                //               icon: Image.asset('assets/icons/wallet.png'),
                //               onPressed: () => Navigator.of(context).push(
                //                   MaterialPageRoute(
                //                       builder: (_) => WalletPage())),
                //             ),
                //             Text(
                //               'Wallet',
                //               style: TextStyle(fontWeight: FontWeight.bold),
                //             )
                //           ],
                //         ),
                //         Column(
                //           mainAxisAlignment: MainAxisAlignment.center,
                //           children: <Widget>[
                //             IconButton(
                //               icon: Image.asset('assets/icons/truck.png'),
                //               onPressed: () => Navigator.of(context).push(
                //                   MaterialPageRoute(
                //                       builder: (_) => TrackingPage())),
                //             ),
                //             Text(
                //               'Shipped',
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.white),
                //             )
                //           ],
                //         ),
                //         Column(
                //           mainAxisAlignment: MainAxisAlignment.center,
                //           children: <Widget>[
                //             IconButton(
                //               icon: Image.asset('assets/icons/card.png'),
                //               onPressed: () => Navigator.of(context).push(
                //                   MaterialPageRoute(
                //                       builder: (_) => PaymentPage())),
                //             ),
                //             Text(
                //               'Payment',
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.white),
                //             )
                //           ],
                //         ),
                //         Column(
                //           mainAxisAlignment: MainAxisAlignment.center,
                //           children: <Widget>[
                //             IconButton(
                //               icon: Image.asset('assets/icons/contact_us.png'),
                //               onPressed: () {},
                //             ),
                //             Text(
                //               'Support',
                //               style: TextStyle(fontWeight: FontWeight.bold),
                //             )
                //           ],
                //         ),
                //       ],
                //     ),
                //   ),
                // ),
                ListTile(
                  title: Text(
                    'Pengaturan',
                    style: TextStyle(color: Colors.white),
                  ),
                  subtitle: Text('Privasi dan pengaturan akun',
                      style: TextStyle(color: Colors.white)),
                  leading: Image.asset(
                    'assets/images/setting-active.png',
                    fit: BoxFit.scaleDown,
                    width: 50,
                    height: 50,
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.white),
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => SettingsPage())),
                ),
                Divider(),
                ListTile(
                  title: Text('Bantuan', style: TextStyle(color: Colors.white)),
                  subtitle: Text('Bantuan dan Support',
                      style: TextStyle(color: Colors.white)),
                  leading: Image.asset(
                    'assets/images/help-active.png',
                    fit: BoxFit.scaleDown,
                    width: 50,
                    height: 50,
                  ),
                  trailing: Icon(
                    Icons.chevron_right,
                    color: Colors.white,
                  ),
                ),
                Divider(),
                ListTile(
                  title: Text('FAQ', style: TextStyle(color: Colors.white)),
                  subtitle: Text('Questions and Answer',
                      style: TextStyle(color: Colors.white)),
                  leading: Image.asset(
                    'assets/images/faq-active.png',
                    fit: BoxFit.scaleDown,
                    width: 50,
                    height: 50,
                  ),
                  trailing: Icon(Icons.chevron_right, color: Colors.white),
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => FaqPage())),
                ),
                Divider(),
                Column(
                  children: <Widget>[
                    Container(
                        width: MediaQuery.of(context).size.width - 50,
                        padding: EdgeInsets.all(25),
                        child: RaisedButton(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(34),
                          ),
                          onPressed: () async {
                            ExtendedNavigator.of(context)
                                .push(Routes.loginPage);
                          },
                          padding: EdgeInsets.all(15),
                          color: HexColor("C52127"),
                          child: Text('Logout',
                              style: TextStyle(color: Colors.white)),
                        ))
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
