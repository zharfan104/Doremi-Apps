import 'package:flutter/material.dart';

class Category{
  Color begin;
  Color end;
  String category;
  String image;

  Category(this.begin, this.end, this.category, this.image);


}