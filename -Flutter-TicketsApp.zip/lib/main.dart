import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:izievent/app_properties.dart';
import 'package:izievent/router.gr.dart';
import 'package:izievent/routes.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IziEvent',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          fontFamily: "Montserrat",
          primaryColor: Colors.white,
          accentColor: Colors.white,
          errorColor: darkAqua,
          textSelectionColor: Colors.white,
          textSelectionHandleColor: Colors.white,
          hintColor: darkGrey),
      builder: ExtendedNavigator.builder<Router>(
        router: Router(),
        initialRoute: '/',
      ),
      // routes: routes
    );
  }
}
