library izievents.globals;

String menuSelected = "Home";