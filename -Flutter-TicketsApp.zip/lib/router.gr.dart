// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

// ignore_for_file: public_member_api_docs

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';

import 'view/filter.dart';
import 'view/home.dart';
import 'view/intro.dart';
import 'view/login.dart';
import 'view/splash.dart';

class Routes {
  static const String InitialRoute = '/';
  static const String loginPage = '/login-page';
  static const String introPage = '/intro-page';
  static const String _homePage = '/home/:isLogin?';
  static String homePage({dynamic isLogin = ''}) => '/home/$isLogin';
  static const String filterPage = '/filter-page';
  static const all = <String>{
    InitialRoute,
    loginPage,
    introPage,
    _homePage,
    filterPage,
  };
}

class Router extends RouterBase {
  @override
  List<RouteDef> get routes => _routes;
  final _routes = <RouteDef>[
    RouteDef(Routes.InitialRoute, page: SplashScreenPage),
    RouteDef(Routes.loginPage, page: LoginPage),
    RouteDef(Routes.introPage, page: IntroPage),
    RouteDef(Routes._homePage, page: HomePage),
    RouteDef(Routes.filterPage, page: FilterPage),
  ];
  @override
  Map<Type, AutoRouteFactory> get pagesMap => _pagesMap;
  final _pagesMap = <Type, AutoRouteFactory>{
    SplashScreenPage: (data) {
      return MaterialPageRoute<dynamic>(
        builder: (context) => const SplashScreenPage(),
        settings: data,
      );
    },
    LoginPage: (data) {
      final args = data.getArgs<LoginPageArguments>(
        orElse: () => LoginPageArguments(),
      );
      return PageRouteBuilder<bool>(
        pageBuilder: (context, animation, secondaryAnimation) =>
            LoginPage(key: args.key),
        settings: data,
        transitionsBuilder: TransitionsBuilders.fadeIn,
      );
    },
    IntroPage: (data) {
      return PageRouteBuilder<bool>(
        pageBuilder: (context, animation, secondaryAnimation) =>
            const IntroPage(),
        settings: data,
        transitionsBuilder: TransitionsBuilders.fadeIn,
      );
    },
    HomePage: (data) {
      final args = data.getArgs<HomePageArguments>(
        orElse: () => HomePageArguments(),
      );
      return PageRouteBuilder<bool>(
        pageBuilder: (context, animation, secondaryAnimation) => HomePage(
          key: args.key,
          isLogin: data.pathParams['isLogin'].intValue,
          index: args.index,
        ),
        settings: data,
        transitionsBuilder: TransitionsBuilders.fadeIn,
      );
    },
    FilterPage: (data) {
      final args = data.getArgs<FilterPageArguments>(
        orElse: () => FilterPageArguments(),
      );
      return PageRouteBuilder<bool>(
        pageBuilder: (context, animation, secondaryAnimation) =>
            FilterPage(key: args.key),
        settings: data,
        transitionsBuilder: TransitionsBuilders.fadeIn,
      );
    },
  };
}

/// ************************************************************************
/// Arguments holder classes
/// *************************************************************************

/// LoginPage arguments holder class
class LoginPageArguments {
  final Key key;
  LoginPageArguments({this.key});
}

/// HomePage arguments holder class
class HomePageArguments {
  final Key key;
  final int index;
  HomePageArguments({this.key, this.index});
}

/// FilterPage arguments holder class
class FilterPageArguments {
  final Key key;
  FilterPageArguments({this.key});
}
